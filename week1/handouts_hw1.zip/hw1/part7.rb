class CartesianProduct
  include Enumerable
  # YOUR CODE HERE
end
